<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>

    <script type="text/javascript" src="view/js/jquery-3.1.0.js"></script>
    <script type="text/javascript" src="view/js/funcionesAdministrador.js"></script>
    <link rel="stylesheet" type="text/css" href="../css/Roboto/WebFont/roboto_regular_macroman/stylesheet.css">
    <link rel="stylesheet" type="text/css" href="../css/estiloBarraNavegacion.css">
    <link rel="stylesheet" type="text/css" href="../css/estilo_principal.css">
  </head>
  <body>
	  <nav class="navAdministrador">
		<div class="opciones">
			<ul>
				<li><a href="mostrar" class="sucursales">Mostrar Sucursales</a></li>
				<li>
					<div class="logo-empresa">
						<img src="../imagenes/coffee-cup-flat-incon.png" width="75">
						<a href="#">El Tostador</a>
					</div>
				</li>
				<li><a href="#" class="">Nombre usuario</a>
					<ul>
						<li><a href="#">Cambiar contraseña</a></li>
						<li><a href="#">Cerrar sesión</a></li>
					</ul>
				</li>
			</ul>
		</div>
	  </nav>
  </body>
</html>
