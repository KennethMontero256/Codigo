<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Inicio</title>
	<link rel="stylesheet" type="text/css" href="../../css/Roboto/WebFont/roboto_regular_macroman/stylesheet.css">
	<link rel="stylesheet" type="text/css" href="../../css/estilo_principal.css">
    <link rel="stylesheet" type="text/css" href="../../css/iconosFuente/style.css">
</head>
<body>
    <?php 
    	include("barraNavegacionPrincipal.php");
    ?>
	<div id="contenedorGlobal">
		<?php 
    		include("../Ventas/GestionVentas.php");
    	?>
	</div>
</body>
</html>