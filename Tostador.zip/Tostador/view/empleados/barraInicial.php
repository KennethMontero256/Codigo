<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <link rel="stylesheet" href="../../css/estiloBarraNavegacion.css">
    </head>
    <body>
        <nav>
            <div class="logo-empresa">
                <img src="../../imagenes/coffee-icon.png">
                <a href="#">El Tostador</a>
            </div>
            <div class="mensaje-bienvenida">
                Bienvenido, debe de iniciar sesión.<p></p>
            </div>
        </nav>
    </body>
</html>