
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <script type="text/javascript" src="../../js/jquery-1.12.3.js"></script>
        <script type="text/javascript" src="../../js/cargar_ventas.js"></script>
        
    </head>
    <body>
        <?php
        
        ?>
        <input id="codigo" value="79">
        <input id="fecha" value="2016-10-23">
        <input type="button" id="boton" >
        
    </body>
</html>
