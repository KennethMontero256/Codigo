<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Recuperación de usuario</title>
	<link rel="stylesheet" href="../../css/estilo_principal.css">
</head>
<body>
	<div class="contenedorModal">
		<form class="recContra" action="" method="get" accept-charset="utf-8">
		 	<p>Recuperación de contraseña</p>
		 	<input type="text" name="" placeholder="Correo">	
			<label class="mensajes"></label>
			<a href="" id="recuperarContraAdministrador" class="btn-submit">Recuperar</a>
			<a href="login.php" id="" class="btn-submit">Regresar</a>
		</form>
	</div>
</body>
</html>