<<<<<<< HEAD
<?php
  define('DB_HOST','68.178.217.43');
  define('DB_USER','ucrgrupo4');
  define('DB_PASS','Grupo#4LkF!');
  define('DB_NAME','ucrgrupo4');

  require("Data/Data.php");
?>
=======
<?php

  define('DB_HOST','localhost');
  define('DB_USER','root');
  define('DB_PASS','');
  define('DB_NAME','u273707874_tosta');
   /*
  define('DB_HOST','68.178.217.43');
  define('DB_USER','ucrgrupo4');
  define('DB_PASS','Grupo#4LkF!');
  define('DB_NAME','ucrgrupo4');
  */
  require('Data/Data.php');
?>
>>>>>>> 203e476e6c4021eab81ceeb1746e493065195151
